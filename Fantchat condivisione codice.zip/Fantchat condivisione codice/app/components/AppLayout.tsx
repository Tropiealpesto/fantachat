"use client";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
