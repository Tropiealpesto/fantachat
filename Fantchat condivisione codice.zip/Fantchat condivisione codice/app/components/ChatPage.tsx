"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import { themeFromType } from "@/lib/competitionThemes";
import TeamBadge, { type BadgePattern } from "./TeamBadge";

type Mention = { user_id: string; team_name: string };
type CitedPlayer = { id: string; name: string; role: string; team: string; image_url?: string | null };
type Meta = { mentions?: Mention[]; players?: CitedPlayer[] } | null;
type Message = {
  id: string; league_id: string; league_competition_id: string | null; user_id: string | null;
  kind: string; content: string | null; meta: Meta; matchday_id: string | null;
  matchday_number: number | null; created_at: string; team_name?: string | null;
};
type Member = { user_id: string; team_name: string; role: string; color_primary?: string | null; color_secondary?: string | null; kit_pattern?: BadgePattern | null };
type Competition = { id: string; name: string; competition_type: string | null };
type PlayerHit = { real_player_id: string; name: string; role: string; team: string; points: number; image_url?: string | null };

type Props = {
  leagueId: string; currentUserId: string; currentTeamName: string;
  activeLeagueCompetitionId?: string | null; competitions?: Competition[];
};

function escapeRe(s: string) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
function activeToken(text: string) {
  const m = text.match(/(@{1,2})([^@\s]*)$/);
  if (!m) return null;
  return { kind: m[1].length === 2 ? "player" : "person", query: m[2], start: text.length - m[0].length };
}
function playerLabel(p: { role: string; name: string; team: string }) { return p.role === "P" ? (p.team || p.name) : p.name; }
function playerSub(p: { role: string; team: string }) { return p.role === "P" ? "Portiere" : `${(p as any).role ?? ""} · ${p.team}`; }

const ROLE_META: Record<string, { bg: string; fg: string }> = {
  P: { bg: "#FEF3C7", fg: "#B45309" },
  D: { bg: "#DCFCE7", fg: "#15803D" },
  C: { bg: "#DBEAFE", fg: "#2563EB" },
  A: { bg: "#FEE2E2", fg: "#DC2626" },
};

function RoleBadge({ role, size = 30 }: { role: string; size?: number }) {
  const c = ROLE_META[role] ?? { bg: "#f1f5f9", fg: "#475569" };

  return (
    <span
      className={`fc-role-badge fc-role-${role}`}
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        display: "inline-grid",
        placeItems: "center",
        background: c.bg,
        color: c.fg,
        fontSize: Math.max(10, size * 0.38),
        fontWeight: 1000,
        border: "1px solid rgba(255,255,255,.9)",
        boxShadow: "0 1px 4px rgba(15,23,42,.08)",
        flexShrink: 0,
      }}
    >
      {role}
    </span>
  );
}

function PlayerChipAvatar({ role, imageUrl, size = 26 }: { role: string; imageUrl?: string | null; size?: number }) {
  const [failed, setFailed] = useState(false);
  const c = ROLE_META[role] ?? { bg: "#f1f5f9", fg: "#475569" };

  if (imageUrl && !failed) {
    return (
      <span
        className="fc-player-avatar"
        style={{
          position: "relative",
          width: size,
          height: size,
          borderRadius: "50%",
          display: "inline-grid",
          placeItems: "center",
          background: "#f1f5f9",
          border: `1px solid ${c.fg}`,
          boxShadow: "0 2px 7px rgba(15,23,42,.12)",
          flexShrink: 0,
        }}
      >
        <img
          src={imageUrl}
          alt=""
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            borderRadius: "50%",
            display: "block",
          }}
        />
        <span
          style={{
            position: "absolute",
            right: -4,
            bottom: -4,
            width: Math.max(12, size * 0.48),
            height: Math.max(12, size * 0.48),
            borderRadius: "50%",
            display: "grid",
            placeItems: "center",
            background: c.fg,
            color: "white",
            border: "1.5px solid white",
            fontSize: Math.max(7, size * 0.28),
            lineHeight: 1,
            fontWeight: 1000,
          }}
        >
          {role}
        </span>
      </span>
    );
  }

  return <RoleBadge role={role} size={size} />;
}

export default function ChatPage({ leagueId, currentUserId, activeLeagueCompetitionId, competitions = [] }: Props) {
  const router = useRouter();
  const [messages, setMessages] = useState<Message[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [pts, setPts] = useState<Record<string, number>>({});
  const [input, setInput] = useState("");
  const [token, setToken] = useState<{ kind: string; query: string; start: number } | null>(null);
  const [playerHits, setPlayerHits] = useState<PlayerHit[]>([]);
  const [mentions, setMentions] = useState<Mention[]>([]);
  const [cited, setCited] = useState<CitedPlayer[]>([]);
  const [playerImages, setPlayerImages] = useState<Record<string, string | null>>({});
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  const endRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const timer = useRef<any>(null);

  const compMap = useMemo(() => new Map(competitions.map((c) => [c.id, c])), [competitions]);
  const memberMap = useMemo(() => new Map(members.map((m) => [m.user_id, m])), [members]);
  const activeComp = activeLeagueCompetitionId ? compMap.get(activeLeagueCompetitionId) : null;
  const theme = themeFromType(activeComp?.competition_type ?? null);
  const accent = theme.primary;

  const loadMessages = useCallback(async () => {
    const { data } = await supabase.rpc("get_chat_messages", { p_league_id: leagueId, p_limit: 200 });
    setMessages((data ?? []) as Message[]);
    setTimeout(() => endRef.current?.scrollIntoView({ behavior: "auto" }), 50);
  }, [leagueId]);

  useEffect(() => {
    let off = false;
    (async () => {
      setLoading(true);
      const [{ data: msgs }, { data: mem }] = await Promise.all([
        supabase.rpc("get_chat_messages", { p_league_id: leagueId, p_limit: 200 }),
        supabase.rpc("get_league_members", { p_league_id: leagueId }),
      ]);
      if (off) return;
      setMessages((msgs ?? []) as Message[]);
      setMembers((mem ?? []) as Member[]);
      setLoading(false);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "auto" }), 60);
    })();
    return () => { off = true; };
  }, [leagueId, loadMessages]);

  useEffect(() => {
    const ch = supabase
      .channel(`chat:${leagueId}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `league_id=eq.${leagueId}` },
        () => { loadMessages(); })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [leagueId, loadMessages]);

  const citedIds = useMemo(
    () => Array.from(new Set(messages.flatMap((m) => (m.meta?.players ?? []).map((p) => p.id)))),
    [messages]
  );

  const imageIds = useMemo(
    () =>
      Array.from(
        new Set([
          ...citedIds,
          ...cited.map((p) => p.id),
          ...playerHits.map((p) => p.real_player_id),
        ].filter(Boolean))
      ),
    [citedIds, cited, playerHits]
  );

  useEffect(() => {
    if (imageIds.length === 0) return;

    let off = false;

    async function loadImages() {
      const { data: players } = await supabase
        .from("real_players")
        .select("id,image_url,real_team_id")
        .in("id", imageIds);

      const teamIds = Array.from(new Set((players ?? []).map((p) => p.real_team_id).filter(Boolean))) as string[];
      let logos = new Map<string, string | null>();

      if (teamIds.length > 0) {
        const { data: teams } = await supabase
          .from("real_teams")
          .select("id,logo_url")
          .in("id", teamIds);

        logos = new Map((teams ?? []).map((team) => [team.id, team.logo_url ?? null]));
      }

      const next: Record<string, string | null> = {};

      for (const player of players ?? []) {
        next[player.id] = player.image_url ?? logos.get(player.real_team_id ?? "") ?? null;
      }

      if (!off) setPlayerImages((prev) => ({ ...prev, ...next }));
    }

    loadImages();

    return () => {
      off = true;
    };
  }, [imageIds]);

  useEffect(() => {
    if (!activeLeagueCompetitionId || citedIds.length === 0) return;
    let off = false;
    async function run() {
      const { data } = await supabase.rpc("chat_player_points", { p_league_competition_id: activeLeagueCompetitionId, p_ids: citedIds });
      if (off || !data) return;
      const map: Record<string, number> = {};
      (data as any[]).forEach((r) => { map[r.real_player_id] = Number(r.points); });
      setPts((prev) => ({ ...prev, ...map }));
    }
    run();
    const iv = setInterval(run, 30000);
    return () => { off = true; clearInterval(iv); };
  }, [citedIds, activeLeagueCompetitionId]);

  function onChange(v: string) {
    setInput(v);
    const t = activeToken(v);
    setToken(t);
    if (t && t.kind === "player") {
      if (timer.current) clearTimeout(timer.current);
      const q = t.query;
      timer.current = setTimeout(async () => {
        if (!activeLeagueCompetitionId) return;
        const { data } = await supabase.rpc("chat_search_players", { p_league_competition_id: activeLeagueCompetitionId, p_q: q });
        setPlayerHits((data ?? []) as PlayerHit[]);
      }, 220);
    }
  }

  function startToken(kind: "person" | "player") {
    const add = kind === "person" ? "@" : "@@";
    const base = input && !input.endsWith(" ") ? input + " " : input;
    const v = base + add;
    setInput(v);
    setToken({ kind, query: "", start: v.length - add.length });
    if (kind === "player" && activeLeagueCompetitionId) {
      supabase.rpc("chat_search_players", { p_league_competition_id: activeLeagueCompetitionId, p_q: "" })
        .then(({ data }) => setPlayerHits((data ?? []) as PlayerHit[]));
    }
    taRef.current?.focus();
  }

  const peopleHits = useMemo(() => {
    if (!token || token.kind !== "person") return [];
    const q = token.query.toLowerCase();
    return members.filter((m) => (m.team_name ?? "").toLowerCase().includes(q)).slice(0, 8);
  }, [token, members]);

  function pickPerson(m: Member) {
    const t = activeToken(input);
    const before = t ? input.slice(0, t.start) : input;
    setInput(before + "@" + m.team_name + " ");
    setMentions((p) => (p.some((x) => x.user_id === m.user_id) ? p : [...p, { user_id: m.user_id, team_name: m.team_name }]));
    setToken(null); taRef.current?.focus();
  }
  function pickPlayer(p: PlayerHit) {
    const t = activeToken(input);
    const before = t ? input.slice(0, t.start) : input;
    setInput(before);
    setCited((c) => (c.some((x) => x.id === p.real_player_id) ? c : [...c, { id: p.real_player_id, name: p.name, role: p.role, team: p.team, image_url: p.image_url ?? playerImages[p.real_player_id] ?? null }]));
    setPts((prev) => ({ ...prev, [p.real_player_id]: Number(p.points) }));
    setToken(null); taRef.current?.focus();
  }

  async function send() {
    const text = input.trim();
    if (!text || sending) return;
    setSending(true);
    const usedMentions = mentions.filter((m) => text.includes("@" + m.team_name));
    const meta = { mentions: usedMentions, players: cited };
    setInput(""); setMentions([]); setCited([]); setToken(null);
    const { data: messageId, error } = await supabase.rpc("send_chat_message", {
      p_league_id: leagueId, p_league_competition_id: activeLeagueCompetitionId ?? null,
      p_matchday_id: null, p_content: text, p_kind: "text", p_meta: meta,
    });
    if (!error) {
      supabase.auth.getSession().then(({ data }) => {
        const accessToken = data.session?.access_token;
        if (!accessToken) return;

        fetch("/api/notifications/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ leagueId, messageId, content: text }),
        }).catch(() => {});
      });
    }
    await loadMessages();
    setSending(false);
  }

  function ptsTag(id: string) {
    const v = pts[id];
    if (v === undefined) return <span style={{ ...s.pts, ...s.ptsFlat }}>·</span>;
    const cls = v > 0 ? s.ptsUp : v < 0 ? s.ptsDown : s.ptsFlat;
    const txt = v > 0 ? "+" + v.toFixed(1) : v.toFixed(1);
    return <span style={{ ...s.pts, ...cls }}>{txt}</span>;
  }

  function renderText(content: string | null) {
    if (!content) return null;
    const tags = mentionsTags(content);
    if (tags.length === 0) return content;
    const re = new RegExp("(" + tags.map(escapeRe).join("|") + ")", "g");
    return content.split(re).map((part, i) =>
      tags.includes(part)
        ? <span key={i} style={{ ...s.mention, color: accent, background: "rgba(21,128,61,.14)" }}>{part}</span>
        : <span key={i}>{part}</span>
    );
  }
  function mentionsTags(content: string) {
    const out: string[] = [];
    for (const m of members) { const tag = "@" + m.team_name; if (content.includes(tag) && !out.includes(tag)) out.push(tag); }
    return out.sort((a, b) => b.length - a.length);
  }

  return (
    <div className="fc-chat-shell" style={s.wrap}>
      <div style={s.stripe} />
      <div className="fc-chat-header" style={s.header}>
        <div>
          <div style={s.hTitle}>Chat lega</div>
          <div style={s.hSub}>{members.length} partecipanti</div>
        </div>
        {activeComp && (
          <div style={{ ...s.livePill, background: theme.badgeBg, color: theme.badgeText }}>
            <span style={{ ...s.liveDot, background: theme.badgeText }} /> {activeComp.name}
          </div>
        )}
      </div>

      <div className="fc-chat-messages" style={s.messages}>
        {loading ? (
          <div style={s.center}>Caricamento...</div>
        ) : messages.length === 0 ? (
          <div style={s.center}>Ancora nessun messaggio. Scrivi il primo!</div>
        ) : (
          messages.map((m, i) => {
            const own = m.user_id === currentUserId;
            if (m.kind && m.kind !== "text") {
              const comp = m.league_competition_id ? compMap.get(m.league_competition_id) : null;
              const isLineup = m.kind === "lineup";
              if (isLineup) {
                return (
                  <div key={m.id} className="fc-chat-lineup-event" style={s.lineupEvent}>
                    <div className="fc-chat-lineup-icon" style={s.lineupIcon} aria-hidden="true">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                        <path d="M8 4l-4 2 2 4 2-1v11h8V9l2 1 2-4-4-2-2 2h-4L8 4z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
                      </svg>
                    </div>
                    <div className="fc-chat-lineup-copy" style={s.lineupCopy}>
                      <span className="fc-chat-lineup-team" style={s.lineupTeam}>{m.team_name ?? "Una squadra"}</span>
                      <span> ha schierato la formazione</span>
                    </div>
                    <button
                      type="button"
                      className="fc-chat-live-button"
                      style={{ ...s.liveButton, color: accent }}
                      onClick={() => router.push("/live")}
                    >
                      Vedi live
                    </button>
                  </div>
                );
              }
              return (
                <div key={m.id} className="fc-chat-event" style={s.event}>
                  <div style={s.eventIco}><span style={{ width: 8, height: 8, borderRadius: "50%", background: "#15803d" }} /></div>
                  <div>
                    <div className="fc-chat-event-text" style={s.eventTxt}>{m.content ?? "Aggiornamento"}</div>
                    <div style={s.eventMeta}>
                      {comp && <span style={{ ...s.tag, ...s.tagComp }}>{comp.name}</span>}
                      {m.matchday_number != null && <span style={s.tag}>Giornata {m.matchday_number}</span>}
                    </div>
                  </div>
                </div>
              );
            }
            const prev = messages[i - 1];
            const head = !prev || prev.user_id !== m.user_id || (prev.kind && prev.kind !== "text");
            const players = m.meta?.players ?? [];
            const author = m.user_id ? memberMap.get(m.user_id) : undefined;
            return (
              <div key={m.id} style={{ ...s.row, flexDirection: own ? "row-reverse" : "row" }}>
                {head ? (
                  <TeamBadge name={m.team_name} primary={author?.color_primary ?? null} secondary={author?.color_secondary ?? null} pattern={author?.kit_pattern ?? "split"} size={30} />
                ) : (
                  <div style={{ width: 30, flexShrink: 0 }} />
                )}
                <div style={{ ...s.col, alignItems: own ? "flex-end" : "flex-start" }}>
                  {head && (
                    <div style={s.who}>
                      {!own && <span style={s.whoName}>{m.team_name ?? "Squadra"}</span>}
                      <span style={s.whoTime}>{new Date(m.created_at).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })}</span>
                      {own && <span style={s.whoName}>Tu</span>}
                    </div>
                  )}
                  <div className={own ? "fc-chat-bubble fc-chat-bubble-own" : "fc-chat-bubble fc-chat-bubble-other"} style={{ ...s.bubble, ...(own ? { background: "#dff5e5", color: "#0f172a", borderTopRightRadius: 4 } : { background: "#ffffff", color: "#0f172a", borderTopLeftRadius: 4, border: "1px solid #eceff3" }) }}>
                    <span style={{ whiteSpace: "pre-wrap" }}>{renderText(m.content)}</span>
                    {players.map((p) => (
                      <span key={p.id} className="fc-chat-player-chip" style={s.pchip}>
                        <PlayerChipAvatar role={p.role} imageUrl={p.image_url ?? playerImages[p.id]} size={26} />
                        <span style={s.pinfo}>
                          <span style={s.pn}>{playerLabel(p)}</span>
                          <span style={s.pt}>{playerSub(p)}</span>
                        </span>
                        {ptsTag(p.id)}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={endRef} />
      </div>

      {/* popup menzioni / giocatori */}
      {token && (token.kind === "person" ? peopleHits.length > 0 : playerHits.length > 0) && (
        <div className="fc-chat-suggest" style={s.ta}>
          <div style={s.taHead}>{token.kind === "person" ? "Menziona un partecipante" : "Cita un giocatore"}</div>
          <div style={s.taList}>
            {token.kind === "person"
              ? peopleHits.map((m) => (
                  <button key={m.user_id} type="button" onMouseDown={(e) => { e.preventDefault(); pickPerson(m); }} className="fc-chat-suggest-row" style={s.taRow}>
                    <TeamBadge name={m.team_name} primary={m.color_primary ?? null} secondary={m.color_secondary ?? null} pattern={m.kit_pattern ?? "split"} size={26} />
                    <span style={s.taName}>{m.team_name}</span>
                  </button>
                ))
              : playerHits.map((p) => (
                  <button key={p.real_player_id} type="button" onMouseDown={(e) => { e.preventDefault(); pickPlayer(p); }} className="fc-chat-suggest-row" style={s.taRow}>
                    <PlayerChipAvatar role={p.role} imageUrl={p.image_url ?? playerImages[p.real_player_id]} size={24} />
                    <span style={s.pinfo}><span style={s.taName}>{playerLabel(p)}</span><span style={s.pt}>{playerSub(p)}</span></span>
                    {ptsTag(p.real_player_id)}
                  </button>
                ))}
          </div>
        </div>
      )}

      {/* giocatori citati in attesa di invio */}
      {cited.length > 0 && (
        <div className="fc-chat-cited" style={s.citedBar}>
          {cited.map((p) => (
            <span key={p.id} style={s.citedChip}>
              <PlayerChipAvatar role={p.role} imageUrl={p.image_url ?? playerImages[p.id]} size={18} />
              {playerLabel(p)}
              <button type="button" onClick={() => setCited((c) => c.filter((x) => x.id !== p.id))} style={s.citedX}>✕</button>
            </span>
          ))}
        </div>
      )}

      <div className="fc-chat-composer" style={s.composer}>
        <button type="button" onClick={() => startToken("person")} className="fc-chat-tool" style={{ ...s.tool, color: "#15803d" }}>@</button>
        <button type="button" onClick={() => startToken("player")} className="fc-chat-tool fc-chat-tool-player" style={{ ...s.tool, color: "#e07b1a", borderColor: "#f4c99d", background: "#fff3e4" }}>P</button>
        <textarea
          ref={taRef} value={input} onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="Scrivi un messaggio..." className="fc-chat-input" style={s.textarea} rows={1}
        />
        <button type="button" onClick={send} disabled={sending || !input.trim()} style={{ ...s.send, background: accent, opacity: sending || !input.trim() ? 0.5 : 1 }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M3 11l18-8-8 18-2-7-8-3z" /></svg>
        </button>
      </div>
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  wrap: { display: "flex", flexDirection: "column", height: "100%", minHeight: 0, background: "#f4f7f4" },
  stripe: { display: "none" },
  header: { background: "rgba(255,255,255,.96)", borderBottom: "1px solid #e5e7eb", padding: "11px 14px", display: "flex", alignItems: "center", gap: 10, boxShadow: "0 2px 10px rgba(15,23,42,.035)", backdropFilter: "blur(14px)" },
  hTitle: { fontWeight: 950, color: "#0f172a", fontSize: 15.5 },
  hSub: { fontSize: 11, color: "#64748b", fontWeight: 700 },
  livePill: { marginLeft: "auto", display: "flex", alignItems: "center", gap: 6, borderRadius: 8, padding: "5px 9px", fontSize: 10.5, fontWeight: 850 },
  liveDot: { width: 6, height: 6, borderRadius: "50%" },
  messages: { flex: 1, minHeight: 0, overflowY: "auto", padding: "10px 12px", display: "flex", flexDirection: "column", gap: 7 },
  center: { margin: "auto", color: "#9ca3af", fontWeight: 800, textAlign: "center" },
  event: { alignSelf: "center", width: "100%", maxWidth: 330, background: "white", border: "1px solid #e5e7eb", borderLeft: "3px solid #15803d", borderRight: "2px solid #f4c99d", borderRadius: 12, padding: "8px 10px", display: "flex", alignItems: "center", gap: 8, boxShadow: "0 2px 10px rgba(15,23,42,.035)" },
  eventIco: { width: 24, height: 24, borderRadius: 7, background: "#dcfce7", display: "grid", placeItems: "center", flexShrink: 0 },
  eventTxt: { fontSize: 12, color: "#0f172a", fontWeight: 800, lineHeight: 1.25 },
  eventMeta: { fontSize: 10.5, color: "#64748b", fontWeight: 800, marginTop: 3, display: "flex", gap: 5, flexWrap: "wrap" },
  tag: { background: "#f1f5f9", borderRadius: 5, padding: "1px 6px", fontWeight: 850, color: "#475569" },
  tagComp: { background: "#dcfce7", color: "#15803d" },
  lineupEvent: { alignSelf: "center", width: "100%", maxWidth: 348, background: "rgba(255,255,255,.92)", border: "1px solid #e5e7eb", borderLeft: "3px solid #15803d", borderRadius: 14, padding: "9px 10px", display: "grid", gridTemplateColumns: "30px minmax(0, 1fr) auto", alignItems: "center", gap: 9, boxShadow: "0 6px 18px rgba(15,23,42,.055)" },
  lineupIcon: { width: 30, height: 30, borderRadius: 10, background: "#e9f7ef", color: "#15803d", display: "grid", placeItems: "center", flexShrink: 0 },
  lineupCopy: { minWidth: 0, color: "#0f172a", fontSize: 12.5, fontWeight: 850, lineHeight: 1.18 },
  lineupTeam: { color: "#15803d", fontWeight: 1000 },
  liveButton: { border: "1px solid rgba(21,128,61,.18)", background: "#e9f7ef", borderRadius: 11, padding: "7px 9px", fontSize: 11, fontWeight: 950, cursor: "pointer", whiteSpace: "nowrap", fontFamily: "inherit" },
  row: { width: "100%", display: "flex", justifyContent: "flex-start", gap: 8, alignItems: "flex-end", maxWidth: "100%" },
  col: { display: "flex", flexDirection: "column", gap: 2, minWidth: 0, maxWidth: "76%" },
  who: { display: "flex", alignItems: "center", gap: 7, padding: "0 2px" },
  whoName: { fontSize: 11.5, fontWeight: 950, color: "#0f172a" },
  whoTime: { fontSize: 10, color: "#94a3b8", fontWeight: 700 },
  bubble: { padding: "9px 11px", borderRadius: 14, fontSize: 13.5, fontWeight: 650, lineHeight: 1.35, display: "flex", flexDirection: "column", gap: 5, boxShadow: "0 6px 18px rgba(15,23,42,.055)" },
  mention: { fontWeight: 1000, borderRadius: 5, padding: "0 3px" },
  pchip: { display: "inline-flex", alignItems: "center", gap: 8, background: "#f8fafc", border: "1px solid #e5e7eb", borderLeft: "3px solid #f4c99d", borderRadius: 10, padding: "6px 8px", alignSelf: "flex-start", maxWidth: "100%" },
  pinfo: { display: "flex", flexDirection: "column", lineHeight: 1.15, minWidth: 0 },
  pn: { fontSize: 12.5, fontWeight: 950, color: "#0f172a", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  pt: { fontSize: 10.5, fontWeight: 700, color: "#64748b" },
  pts: { marginLeft: 2, fontSize: 12, fontWeight: 850, padding: "2px 7px", borderRadius: 7, flexShrink: 0 },
  ptsUp: { background: "#dcfce7", color: "#15803d" },
  ptsDown: { background: "#fee2e2", color: "#dc2626" },
  ptsFlat: { background: "#f1f5f9", color: "#64748b" },
  ta: { margin: "0 12px", background: "white", border: "1px solid #e5e7eb", borderRadius: 12, boxShadow: "0 10px 24px rgba(15,23,42,.12)", overflow: "hidden" },
  taHead: { fontSize: 10, fontWeight: 1000, color: "#64748b", textTransform: "uppercase", letterSpacing: ".04em", padding: "9px 13px 5px" },
  taList: { maxHeight: 240, overflowY: "auto", display: "flex", flexDirection: "column" },
  taRow: { display: "flex", alignItems: "center", gap: 10, padding: "9px 13px", borderTop: "1px solid #f1f5f9", background: "white", border: "none", cursor: "pointer", textAlign: "left", fontFamily: "inherit", width: "100%" },
  taName: { fontSize: 13, fontWeight: 900, color: "#0f172a" },
  citedBar: { display: "flex", gap: 6, flexWrap: "wrap", padding: "8px 12px 0" },
  citedChip: { display: "inline-flex", alignItems: "center", gap: 6, background: "white", border: "1px solid #e5e7eb", borderRadius: 9, padding: "4px 8px", fontSize: 12, fontWeight: 800, color: "#0f172a" },
  citedX: { border: "none", background: "#e5e7eb", color: "#374151", width: 18, height: 18, borderRadius: 6, fontWeight: 900, cursor: "pointer", fontSize: 10, lineHeight: 1 },
  composer: { flexShrink: 0, background: "rgba(248,251,248,.96)", borderTop: "1px solid #e5e7eb", padding: "8px 10px", display: "flex", alignItems: "center", gap: 7, boxShadow: "0 -4px 14px rgba(15,23,42,.045)" },
  tool: { width: 34, height: 34, borderRadius: 10, background: "#fff", border: "1px solid #e5e7eb", color: "#64748b", fontWeight: 850, fontSize: 14, cursor: "pointer", flexShrink: 0, display: "grid", placeItems: "center" },
  textarea: { flex: 1, border: "1px solid #e5e7eb", borderRadius: 12, padding: "8px 11px", resize: "none", fontFamily: "inherit", fontSize: 13.5, fontWeight: 600, maxHeight: 96, background: "#fff" },
  send: { width: 38, height: 38, borderRadius: 12, border: 0, color: "white", fontWeight: 900, cursor: "pointer", flexShrink: 0, display: "grid", placeItems: "center" },
};
